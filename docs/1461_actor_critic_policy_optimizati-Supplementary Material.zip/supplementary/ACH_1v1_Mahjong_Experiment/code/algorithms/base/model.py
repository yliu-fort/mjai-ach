from config.config_mahjong import Config

class Model(object):

    def __init__(self, *args):
        self.feature_dim = Config.INPUT_DIM
        self.feature_shape = list(self.feature_dim)
        self.feature_shape.insert(0, -1)
        self.action_dim = Config.ACTION_DIM

        self.state_dim = Config.INPUT_DIM
        self.action_dim = Config.ACTION_DIM
        self.T = Config.T
        self.with_random = True

    def inference(self, feature):
        raise NotImplementedError("build model: not implemented!")