from proto.gym_rl_pb2 import OfflineRlInfo
import numpy as np

class OfflineRlInfoAdapter(object):

    def __init__(self):
        self.rl_info = OfflineRlInfo()

    def deserialization(self, receive_data):
        data = []
        self.rl_info.ParseFromString(receive_data)

        #raise NotImplementedError("deserialization: not implemented")

        #check data correction
        """
        filename = "data_{}.txt".format(str(frame_no))
        obs = np.reshape(feature, [84, 84 ,4])
        fo = open(filename, "w")
        content = "frame_no: " + str(frame_no) + "\n"
        fo.write(content)
        for idx in range(4):
            for row_idx in range(84):
                content = ""
                for col_idx in range(84):
                     content += str(int(obs[row_idx, col_idx, idx]))
                     content += "\t"
                content += "\n"
                fo.write(content)
        content = str(reward_sum[0]) + "\t" + str(advantage[0]) + "\t" + str(action[0]) + "\t" + str(neg_log_pi[0]) + "\t" + str(value[0]) + "\n"
        fo.write(content)
        """
        return data
