import tensorflow as tf
import platform
import shutil
import importlib
from config.config_mahjong import Config
import os

algorithm = Config.ALGORITHM
model = importlib.import_module("algorithms." + algorithm + ".model")
algorithm = importlib.import_module("algorithms." + algorithm + ".algorithm")

model = model.Model()
network = algorithm.Algorithm(model)

data = tf.zeros(shape=[Config.BATCH_SIZE, 534], dtype=tf.float32)
loss, info_list = network.build_graph(data, tf.train.get_or_create_global_step())


