### Introduction
ACH is a model-free actor-critic algorithm for approximating a Nash equilibrium in large-scale imperfect-information games.

### Declaration 
The experiments on the 1v1 Mahjong benchmark were run in a large cluster of thousands of machines, on which we have developed an 
efficient actor-learner training platform. The codes of both the platform and the 1v1 Mahjong benchmark are not released currently but are planned to be open sourced in the near future. Yet, the codes for both the actor part and the learner part of each algorithm (PPO, RPG, NeuRD, and ACH) are included in the supplementary materials.




























