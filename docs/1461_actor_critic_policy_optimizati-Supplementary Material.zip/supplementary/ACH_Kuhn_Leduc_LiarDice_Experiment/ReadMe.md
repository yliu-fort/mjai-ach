### Preparation
Install the DeepMind OpenSpiel Environment: https://github.com/deepmind/open_spiel

### Train
```Shell
python ach_example.py
```
The default hyperparameters are for ACH. 

For other algorithms:
From https://github.com/deepmind/open_spiel/issues/155
e.g. Train RPG on Leduc Poker with: ```python ach_example.py  -loss_str=rpg -critic_lr=0.01 -nctopi=32 -pi_lr=0.01 -seed_=1```

All results are run under random seeds 1 to 8. 

The experimental results are stored in the ```log```, and the trained agent is stored in the ```tmp```. 






























